# SBI Smart Remote Access Fraud Protection Layer

A beginner-friendly **bank-side security-layer prototype** that demonstrates simulated remote-access and payment-risk analysis.

## Scope and safety
This is an educational prototype only. It is not affiliated with or integrated into SBI, NPCI, UPI, or any live banking system. It cannot inspect device-wide remote-access activity by itself and cannot block real payments. Device signals in this version are simulated inputs.

## Repository
- `backend/` – FastAPI backend, SQLite persistence, signal analysis, transparent rule-based risk scoring, advisory decisions, and transaction history.

See [backend/README.md](backend/README.md) for setup and API examples.
