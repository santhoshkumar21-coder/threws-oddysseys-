from .risk_engine import RiskAssessment

def build_decision(assessment: RiskAssessment) -> dict:
    """Return an advisory decision; this prototype never blocks a real payment."""
    guidance = {
        "LOW": "No configured warning signals. Continue only in the simulated demo.",
        "MEDIUM": "Ask for an additional trusted verification step in a real deployment.",
        "HIGH": "Recommend pausing the simulated flow and sending the case for trained human review.",
    }
    return {
        "risk_score": assessment.score,
        "risk_level": assessment.level,
        "recommendation": assessment.recommendation,
        "guidance": guidance[assessment.level],
        "reasons": assessment.reasons,
    }
