from ..schemas import PaymentAnalysisRequest

def analyze_signals(payment: PaymentAnalysisRequest) -> list[str]:
    """Convert supplied simulation flags into readable security observations."""
    observations = []
    if payment.remote_access_active:
        observations.append("Remote-access session is reported as active.")
    if payment.screen_sharing_active:
        observations.append("Screen-sharing session is reported as active.")
    if payment.remote_control_active:
        observations.append("Remote-control activity is reported as active.")
    if payment.unknown_app_detected:
        observations.append("An unrecognised app is reported by the simulator.")
    if payment.unusual_device:
        observations.append("Device differs from the customer's usual device (simulated).")
    if payment.rapid_transactions:
        observations.append("Rapid repeated transactions are reported (simulated).")
    return observations
