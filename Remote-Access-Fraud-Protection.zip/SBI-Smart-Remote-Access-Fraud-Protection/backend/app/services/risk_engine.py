from dataclasses import dataclass
from ..schemas import PaymentAnalysisRequest
from ..config import RISK_LOW_MAX, RISK_MEDIUM_MAX

@dataclass
class RiskAssessment:
    score: int
    level: str
    recommendation: str
    reasons: list[str]

def calculate_risk(payment: PaymentAnalysisRequest) -> RiskAssessment:
    """Transparent rule-based score for demonstration; not a validated bank model."""
    score = 0
    reasons = []

    rules = [
        (payment.remote_access_active, 25, "Active remote-access signal"),
        (payment.screen_sharing_active, 20, "Active screen-sharing signal"),
        (payment.remote_control_active, 30, "Active remote-control signal"),
        (payment.unknown_app_detected, 10, "Unrecognised app signal"),
        (payment.unusual_device, 10, "Unusual device signal"),
        (payment.rapid_transactions, 15, "Rapid transaction pattern"),
    ]
    for triggered, points, reason in rules:
        if triggered:
            score += points
            reasons.append(f"{reason} (+{points})")

    # A high amount alone does not prove fraud; it adds only a small review signal.
    if payment.amount >= 100000:
        score += 5
        reasons.append("High-value payment review signal (+5)")

    score = min(score, 100)
    if score <= RISK_LOW_MAX:
        level, recommendation = "LOW", "ALLOW_SIMULATED"
    elif score <= RISK_MEDIUM_MAX:
        level, recommendation = "MEDIUM", "STEP_UP_VERIFICATION"
    else:
        level, recommendation = "HIGH", "HOLD_FOR_HUMAN_REVIEW"

    if not reasons:
        reasons.append("No configured risk signals were triggered.")

    return RiskAssessment(score, level, recommendation, reasons)
